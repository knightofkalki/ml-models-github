# Sentiment Classification using CNN from Facial Images

This project is a **Convolutional Neural Network (CNN)** based **Image Sentiment Classifier** that detects whether a person in a given image is **happy** or **sad**.

## 📌 Overview

- **Input**: Image of a person's face (e.g., JPG/PNG)
- **Output**: Sentiment classification - `happy` or `sad`
- **Model Type**: CNN (Convolutional Neural Network)
- **Framework**: TensorFlow/Keras (from notebook)

---

## 📁 Folder Structure

model1-cnn-sentiment/ ├── CNN_Classifier.ipynb # Main model training and testing notebook ├── sentiment_classifier.ipynb # Additional implementation or test notebook ├── data/ │ ├── happy.jpg │ ├── happyl.jpg │ └── sadperson.jpg # Sample images used in training/testing ├── logs/ # Model logs or checkpoints (optional) ├── extras/ │ ├── Untitled.ipynb │ ├── Untitled1.ipynb │ └── Untitled2.ipynb # Miscellaneous/temporary notebooks └── README.md # Project description (this file)


---

## 🚀 How to Run

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/ml-models-github.git
   cd ml-models-github/model1-cnn-sentiment
Install required packages: (You may create a requirements.txt if needed)
pip install tensorflow matplotlib numpy
Open the Jupyter Notebook:
jupyter notebook CNN_Classifier.ipynb
Upload your own image or use the sample ones in the data/ folder.
🧠 Model Info

Uses Convolutional layers with ReLU activation
Flattened output fed into Dense layers
Binary classification using sigmoid activation
Trained on a small dataset of labeled facial expressions
📷 Example Input & Output

Input Image	Prediction
happy.jpg	😀 Happy
sadperson.jpg	😢 Sad
🔮 Future Work

Increase dataset size for better generalization
Add more classes like neutral, angry, surprised
Build a web interface for real-time prediction
🧑‍💻 Author
22BCE2766	SANJANA R
22BCE3169	APOORVA SALUJA
22BCE3499	UJJWAL AGGARWAL


